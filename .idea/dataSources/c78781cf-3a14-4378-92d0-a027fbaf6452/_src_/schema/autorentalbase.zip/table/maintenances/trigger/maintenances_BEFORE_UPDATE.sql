CREATE TRIGGER maintenances_BEFORE_UPDATE
BEFORE UPDATE ON maintenances
FOR EACH ROW
  BEGIN
	if ((new.maintenance_date_begin)>(new.maintenance_date_expir)) then
		SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Дата окончания не может быть до даты начала';
	end if;
END;
