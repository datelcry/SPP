CREATE TRIGGER `bills_has_services_AFTER_UPDATE`
AFTER UPDATE ON `bills_has_services`
FOR EACH ROW
  BEGIN
	call cost_bill(new.service_bill);
END