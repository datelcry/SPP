CREATE TRIGGER `inspections_BEFORE_UPDATE`
BEFORE UPDATE ON `inspections`
FOR EACH ROW
  BEGIN
	if ((new.inspection_date_begin)>(new.inspection_date_expir)) then
		SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Дата окончания не может быть до даты начала';
	end if;
END