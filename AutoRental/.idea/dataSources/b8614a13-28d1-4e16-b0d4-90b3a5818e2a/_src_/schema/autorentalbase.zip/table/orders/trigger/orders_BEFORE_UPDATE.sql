CREATE TRIGGER `orders_BEFORE_UPDATE`
BEFORE UPDATE ON `orders`
FOR EACH ROW
  BEGIN
	if ((new.order_date_begin)>(new.order_date_expir)) then
		SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Дата окончания не может быть до даты начала';
	end if;
END