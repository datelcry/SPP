CREATE TRIGGER `insurances_BEFORE_INSERT`
BEFORE INSERT ON `insurances`
FOR EACH ROW
  BEGIN
	if ((new.insurance_date_begin)>(new.insurance_date_expir)) then
		SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Дата окончания не может быть до даты начала';
	end if;
END