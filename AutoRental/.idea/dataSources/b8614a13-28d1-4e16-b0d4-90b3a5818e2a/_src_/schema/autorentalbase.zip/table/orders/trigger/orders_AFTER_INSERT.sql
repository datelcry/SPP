CREATE TRIGGER `orders_AFTER_INSERT`
AFTER INSERT ON `orders`
FOR EACH ROW
  BEGIN
	declare bill int;
    set bill = (select distinct bills.bill_id from orders join bills on bills.bill_order=new.order_id);
	if (bill is not null)
    then
	begin
		call cost_bill(bill);
    end;
    end if;
END