CREATE PROCEDURE `cost_bill`(IN `id` INT(11))
  BEGIN
	declare cost float;
    declare days int;
    declare date_begin date;
    declare date_expir date;
    declare procent float;
    select sum(service_cost) from bills 
    join bills_has_services on bills_has_services.service_bill=bills.bill_id
    join services on services.service_id=bills_has_services.bill_service
    where bill_id=id into cost;
    select order_date_begin from bills join orders on orders.order_id=bills.bill_order where bill_id=id into date_begin;
    select order_date_expir from bills join orders on orders.order_id=bills.bill_order where bill_id=id into date_expir;
    select datediff(date_expir,date_begin) into days;
    if (days<8) then
    begin
		set cost=cost+(select tariffes.tariff_1_to_7 from bills join orders on order_id=bill_order
		join cars on car_id=order_car
		join tariffes on tariff_id=car_tariff
		where bill_id=id);
    end;
    elseif (days<15) then
    begin
		set cost=cost+(select tariffes.tariff_8_to_14 from bills join orders on order_id=bill_order
		join cars on car_id=order_car
		join tariffes on tariff_id=car_tariff
		where bill_id=id);
    end;
    else
    begin
		set cost=cost+(select tariffes.tariff_15_to_30 from bills join orders on order_id=bill_order
		join cars on car_id=order_car
		join tariffes on tariff_id=car_tariff
		where bill_id=id);
    end;
    end if;
    set procent = 100 - (select discounts.discount_value from bills join discounts  on bill_discount=discount_id where bill_id=id);
    set cost = cost*procent/100;
    update bills set bill_cost=cost where bill_id=id;
END