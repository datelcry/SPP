CREATE PROCEDURE `cost_bill`(IN `id` INT(11))
  BEGIN
	declare cost float;
    declare days int;
    declare date_begin date;
    declare date_expir date;
    declare procent float;
    set cost=0;
    select sum(service_cost) from bills 
    join bills_has_services on bills_has_services.service_bill=bills.bill_id
    join services on services.service_id=bills_has_services.bill_service
    where bill_id=id into cost;
    if (cost is null) then
    begin
		set cost=0;
    end;
    end if;
    select order_date_begin from bills join orders on orders.order_id=bills.bill_order where bill_id=id into date_begin;
    select order_date_expir from bills join orders on orders.order_id=bills.bill_order where bill_id=id into date_expir;
    select datediff(date_expir,date_begin) into days;
    set cost = cost+days*(select brands.brand_tariff from bills 
		join orders on order_id=bill_order
		join cars on car_id=order_car 
        join brands on brand_id=car_brand
        where bill_id=id);
    set procent = 100 - (select discounts.discount_value from bills join discounts on bill_discount=discount_id where bill_id=id);
    set cost = cost*procent/100;
    update bills set bill_cost=cost where bill_id=id;
END